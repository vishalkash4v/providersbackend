const mongoose = require('mongoose');

const bookingCreditTransactionSchema =
  new mongoose.Schema(
    {
      provider: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true,
      },

      type: {
        type: String,
        enum: [
          'referral_reward',
          'subscription_purchase',
          'booking_used',
          'admin_credit',
          'admin_debit',
          'refund',
          'booking_cancelled',
          'expiry',
        ],
        required: true,
        index: true,
      },

      amount: {
        type: Number,
        required: true,
      },

      balanceBefore: {
        type: Number,
        required: true,
      },

      balanceAfter: {
        type: Number,
        required: true,
      },

      // Human readable reason
      description: {
        type: String,
        default: '',
      },

      // Referral which generated credits
      referral: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Referral',
        default: null,
      },

      // Booking where credits were consumed
      booking: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Booking',
        default: null,
      },

      // Subscription which generated credits
      subscription: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ProviderSubscription',
        default: null,
      },

      // Useful for preventing duplicate transactions
      referenceId: {
        type: String,
        default: null,
        index: true,
      },
    },
    {
      timestamps: true,
    }
  );

bookingCreditTransactionSchema.index({
  provider: 1,
  createdAt: -1,
});

module.exports =
  mongoose.model(
    'BookingCreditTransaction',
    bookingCreditTransactionSchema
  );