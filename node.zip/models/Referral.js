const mongoose = require('mongoose');

const referralSchema = new mongoose.Schema(
  {
    // Provider who invited
    referrer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    // Provider who was invited
    referredUser: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    referralCode: {
      type: String,
      required: true,
    },

    status: {
      type: String,
      enum: ['PENDING', 'SUCCESS'],
      default: 'PENDING',
      index: true,
    },

    // First job/order that made referral successful
    firstBooking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      default: null,
    },

    // Credits given to referrer
    rewardCredits: {
      type: Number,
      default: 0,
    },

    completedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model(
  'Referral',
  referralSchema
);