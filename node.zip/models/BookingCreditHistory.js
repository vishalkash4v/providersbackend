const mongoose = require('mongoose');

const bookingCreditHistorySchema = new mongoose.Schema(
  {
    provider: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    type: {
      type: String,
      enum: ['ADD', 'USE'],
      required: true,
    },

    source: {
      type: String,
      enum: [
        'REFERRAL',
        'SUBSCRIPTION',
        'BOOKING',
        'ADMIN',
        'REFUND',
      ],
      required: true,
    },

    credits: {
      type: Number,
      required: true,
      min: 1,
    },

    balanceBefore: {
      type: Number,
      required: true,
    },

    balanceAfter: {
      type: Number,
      required: true,
    },

    referralUser: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },

    booking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      default: null,
    },

    subscription: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subscription',
      default: null,
    },

    description: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model(
  'BookingCreditHistory',
  bookingCreditHistorySchema
);