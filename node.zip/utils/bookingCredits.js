const User = require('../models/User');
const BookingCreditHistory = require('../models/BookingCreditHistory');

const FREE_JOBS_PER_REFERRAL =
  Number(process.env.PROVIDER_FREE_JOBS_PER_REFERRAL || 3);


// ============================================================
// ADD BOOKING CREDITS
// ============================================================

const addBookingCredits = async ({
  providerId,
  credits,
  source,
  description = '',
  referralUser = null,
  subscription = null,
}) => {
  const user = await User.findById(providerId);

  if (!user) {
    throw new Error('Provider not found');
  }

  const balanceBefore =
    Number(user.bookingCredits || 0);

  const balanceAfter =
    balanceBefore + Number(credits);

  user.bookingCredits =
    balanceAfter;

  user.bookingCreditsEarned =
    Number(user.bookingCreditsEarned || 0) +
    Number(credits);

  await user.save();

  await BookingCreditHistory.create({
    provider: providerId,
    type: 'ADD',
    source,
    credits,
    balanceBefore,
    balanceAfter,
    referralUser,
    subscription,
    description,
  });

  return user;
};


// ============================================================
// USE ONE BOOKING CREDIT
// ============================================================

const useBookingCredit = async ({
  providerId,
  bookingId,
}) => {
  const user = await User.findById(providerId);

  if (!user) {
    throw new Error('Provider not found');
  }

  const currentBalance =
    Number(user.bookingCredits || 0);

  if (currentBalance <= 0) {
    return {
      success: false,
      message:
        'You do not have any booking credits. Please purchase a subscription or earn credits through referrals.',
    };
  }

  const balanceAfter =
    currentBalance - 1;

  user.bookingCredits =
    balanceAfter;

  user.bookingCreditsUsed =
    Number(user.bookingCreditsUsed || 0) + 1;

  await user.save();

  await BookingCreditHistory.create({
    provider: providerId,
    type: 'USE',
    source: 'BOOKING',
    credits: 1,
    balanceBefore: currentBalance,
    balanceAfter,
    booking: bookingId,
    description: 'Booking credit used',
  });

  return {
    success: true,
    balance: balanceAfter,
  };
};


module.exports = {
  FREE_JOBS_PER_REFERRAL,
  addBookingCredits,
  useBookingCredit,
};